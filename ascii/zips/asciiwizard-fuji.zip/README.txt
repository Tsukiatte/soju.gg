asciiwizard fuji

1. Open a terminal in this folder.
2. python -m http.server 8000   (or: npx serve)
3. Open http://localhost:8000/run.html

Module scripts need a local server; double-clicking run.html will not work.
Edit scenes/fuji.js and reload to change the picture.
